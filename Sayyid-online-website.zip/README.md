# Sayyid Online

Digital Social Media Marketing website.

## Files
- `index.html` — website structure
- `style.css` — responsive design
- `script.js` — mobile navigation

## Run
Open `index.html` in a browser, or publish the repository with GitHub Pages.
